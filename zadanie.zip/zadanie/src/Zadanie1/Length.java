package Zadanie1;

public class Length {
}
