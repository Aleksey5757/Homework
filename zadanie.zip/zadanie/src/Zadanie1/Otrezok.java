package Zadanie1;

public class Otrezok {          //создали класс
    double coordinate_x1; double coordinate_y1; // первая точка
    double coordinate_x2; double coordinate_y2; // вторая точка

    public Otrezok(double coordinate_x1, double coordinate_y1, double coordinate_x2, double coordinate_y2) { //создали конструктор
        this.coordinate_x1 = coordinate_x1;
        this.coordinate_y1 = coordinate_y1;
        this.coordinate_x2 = coordinate_x2;
        this.coordinate_y2 = coordinate_y2;
    }
}

