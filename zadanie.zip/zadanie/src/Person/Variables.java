package Person;

public class Variables {

    String fullName;
    int age;

    void move (String name) {
        System.out.println();
    }

}
